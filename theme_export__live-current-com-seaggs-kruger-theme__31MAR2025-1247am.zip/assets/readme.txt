 ░▒▓███████▓▒░▒▓████████▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░ ░▒▓██████▓▒░ ░▒▓███████▓▒░ 
░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░        
░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░        
 ░▒▓██████▓▒░░▒▓██████▓▒░ ░▒▓████████▓▒░▒▓█▓▒▒▓███▓▒░▒▓█▓▒▒▓███▓▒░░▒▓██████▓▒░  
       ░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░ 
       ░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░ 
░▒▓███████▓▒░░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓███████▓▒░  
                      A THEME THATS UNLIKE ANY OTHER 

    Theme Name: Oynx
        Theme Designer: SEAGGS
          Theme Developer: IMMOTI studios
            Theme Version: 0.2.2
                Theme URI: https://seaggs.com
                    Theme Documentation: None at the moment.
                        Terms of use: https://seaggs.com/terms-of-use
                        Terms of sales: https://seaggs.com/terms-of-sales
                        Privacy policy: https://seaggs.com/privacy-policy
                            Report a bug: https://feedback.seaggs.com/pages/bug-reports/
                            Request a new feature: https://feedback.seaggs.com/pages/feature-requests/
                

                                       \\\\\\\\\\\   Copyright SEAGGS Inc. All rights reserved. ///////////





















































                                              [made for SEAGGS, my good friend in California.]